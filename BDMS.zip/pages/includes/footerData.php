<footer>
	<p>&copy;
		<?php echo date("Y"); ?>: Blood Donor Management System || A Fall Project
	</p>
</footer>
<style>
	footer {
		background-color: #424558;
		bottom: 0;
		left: 0;
		right: 0;
		height: 35px;
		text-align: center;
		color: #CCC;
	}

	footer p {
		padding: 10.5px;
		margin: 0px;
		line-height: 100%;
	}
</style>